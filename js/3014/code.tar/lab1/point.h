typedef struct {
  double x;
  double y;
} point;


